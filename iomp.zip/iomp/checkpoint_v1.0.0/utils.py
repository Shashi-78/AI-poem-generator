"""
Utility functions for the AI Poem Generator.

This file contains helper functions for text processing, poem extraction, and memory management.
"""

import re
import torch
import os
import logging
from typing import List, Dict, Any, Optional

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("poem_generator")

def clean_up_memory() -> None:
    """Clean up GPU memory."""
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        logger.info("GPU memory cleared")

def preprocess_text(text: str) -> str:
    """
    Clean and normalize text.
    
    Args:
        text: Input text
        
    Returns:
        Cleaned text
    """
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text.strip())
    
    # Remove URLs
    text = re.sub(r'http\S+|www\S+|https\S+', '', text)
    
    # Remove special characters but preserve poetry punctuation
    text = re.sub(r'[^\w\s.,;:!?\'"-]', ' ', text)
    
    # Normalize whitespace again
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

def post_process_poem(poem: str) -> str:
    """Improved post-processing function that formats the poem with proper line breaks."""
    lines = poem.split('\n')
    processed = []
    
    for line in lines:
        # Clean up whitespace
        line = line.strip()
        if not line:
            continue
            
        # Fix line breaks in the middle of sentences
        if len(processed) > 0 and not processed[-1].endswith(('.', '!', '?', ':', ';', '-', '—')):
            # If previous line doesn't end with punctuation and this line starts with lowercase
            if not line[0].isupper() and not line[0].isdigit():
                # Append to previous line instead of creating a new one
                processed[-1] += ' ' + line
                continue
        
        processed.append(line)
        
    return '\n'.join(processed)

def extract_poem_from_text(generated_text: str, prompt: str) -> str:
    """
    Extract the actual poem from generated text.
    Simplified approach that extracts poetic content and cleans it up.
    """
    logger.info("Starting poem extraction...")
    try:
        # Remove the prompt from the beginning
        if generated_text.startswith(prompt):
            poem_text = generated_text[len(prompt):].strip()
        else:
            poem_text = generated_text.strip()
            
        # First pass: Split into paragraphs and remove empty ones
        paragraphs = poem_text.split('\n\n')
        
        # If we have multiple paragraphs, use the first substantial one
        if len(paragraphs) > 1:
            for para in paragraphs:
                # Skip very short paragraphs
                if len(para.strip()) > 30:
                    poem_text = para.strip()
                    break
        
        # Split into lines
        lines = []
        for line in poem_text.split('\n'):
            line = line.strip()
            if not line:
                continue
                
            # Split very long lines into multiple lines (they might be prose)
            if len(line) > 60 and ' ' in line:
                words = line.split()
                current_line = ""
                for word in words:
                    if len(current_line) + len(word) + 1 > 50:  # +1 for the space
                        if current_line:
                            lines.append(current_line)
                        current_line = word
                    else:
                        if current_line:
                            current_line += " " + word
                        else:
                            current_line = word
                if current_line:
                    lines.append(current_line)
            else:
                lines.append(line)
        
        if not lines:
            return "The model didn't generate any poem content. Please try again."
        
        # Filter out unwanted content
        filtered_lines = []
        for i, line in enumerate(lines):
            # Skip lines with clear non-poem markers
            if any(marker in line.lower() for marker in ['http://', 'www.', '@', '#', 'copyright']):
                continue
                
            # Skip attribution lines typically at the end
            if i > 2 and (line.startswith('--') or line.startswith('- ') or line.startswith('by ')):
                continue
                
            # Skip lines that are all uppercase (likely headers)
            if line.isupper() and len(line) > 10:
                continue
                
            # Skip parenthetical notes
            if line.startswith('(') and line.endswith(')'):
                continue
                
            # Skip excessively punctuated lines
            if sum(c == '!' for c in line) > 3 or sum(c == '?' for c in line) > 3:
                continue
                
            filtered_lines.append(line)
        
        # Apply style-specific limits and expectations
        if "sonnet" in prompt.lower():
            # Sonnets should have around 14 lines
            poem_lines = filtered_lines[:min(14, len(filtered_lines))]
        elif "haiku" in prompt.lower() and len(filtered_lines) >= 3:
            # Haikus should have exactly 3 lines
            poem_lines = filtered_lines[:3]
        elif "limerick" in prompt.lower() and len(filtered_lines) >= 5:
            # Limericks should have 5 lines
            poem_lines = filtered_lines[:5]
        else:
            # For other styles, use a reasonable number
            poem_lines = filtered_lines[:min(12, len(filtered_lines))]
            
        # Make sure we have enough lines
        if len(poem_lines) < 2:
            # If we don't have enough lines, fall back to original text but clean it up
            words = poem_text.split()
            lines = []
            current_line = ""
            
            for word in words:
                if len(current_line) + len(word) + 1 > 50:  # +1 for space
                    lines.append(current_line)
                    current_line = word
                else:
                    if current_line:
                        current_line += " " + word
                    else:
                        current_line = word
                        
            if current_line:
                lines.append(current_line)
                
            poem_lines = lines[:min(8, len(lines))]
        
        # Clean up each line
        final_lines = []
        for line in poem_lines:
            # Remove excessive spaces
            line = re.sub(r'\s+', ' ', line.strip())
            
            # Fix spacing before punctuation
            line = re.sub(r'\s+([.,;:!?])', r'\1', line)
            
            # Remove any trailing punctuation that looks messy
            line = re.sub(r'[.,;:!?]+$', '', line)
            
            # If the line is very short, skip it
            if len(line) < 2:
                continue
                
            final_lines.append(line)
        
        # Double check that we have something to return
        if not final_lines:
            return "The model didn't generate a proper poem. Please try again."
            
        # Join lines and apply post-processing to improve formatting
        raw_poem = '\n'.join(final_lines)
        final_poem = post_process_poem(raw_poem)
        
        logger.info(f"Successfully extracted poem with {len(final_lines)} lines")
        return final_poem
        
    except Exception as e:
        logger.error(f"Error extracting poem: {str(e)}")
        return "Error extracting poem. Please try again with different keywords."

def save_poem_to_file(poem: str, filename: str, metadata: Optional[Dict[str, Any]] = None) -> str:
    """
    Save a generated poem to a file with optional metadata.
    Always creates the outputs directory if it doesn't exist.
    """
    # Ensure the output directory exists
    output_dir = 'outputs'
    os.makedirs(output_dir, exist_ok=True)
    
    # Add .txt extension if not present
    if not filename.endswith('.txt'):
        filename += '.txt'
    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write("=== Generated Poem ===\n\n")
        if metadata:
            f.write("Generated with:\n")
            for key, value in metadata.items():
                f.write(f"- {key}: {value}\n")
            f.write("\n")
        
        # Write poem with proper line breaks
        f.write(poem)
    logger.info(f"Poem saved to {filepath}")
    return filepath 