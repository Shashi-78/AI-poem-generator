"""
AI Poem Generator

A streamlined poem generation system using gpt2 for generating poetry based on user-provided keywords.
"""

import argparse
import os
import torch
from transformers import pipeline, AutoTokenizer
from pathlib import Path
import logging
from typing import Dict, List, Optional, Any
import random

# Import settings and utilities
from settings import GENERATION_SETTINGS, OUTPUT_DIR, MODEL_SETTINGS, DEFAULT_PROMPTS
from utils import (
    clean_up_memory,
    extract_poem_from_text,
    preprocess_text,
    save_poem_to_file
)

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("poem_generator")

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="AI Poem Generator")
    parser.add_argument(
        "--keywords",
        type=str,
        default="ocean,sunset,silence",
        help="Comma-separated keywords for the poem"
    )
    parser.add_argument(
        "--style",
        type=str,
        default="free verse",
        choices=["free verse", "haiku", "sonnet", "limerick", "ballad", "acrostic"],
        help="Poetry style"
    )
    parser.add_argument(
        "--emotion",
        type=str,
        default=None,
        help="Emotion to express in the poem"
    )
    parser.add_argument(
        "--output_file",
        type=str,
        default="generated_poem.txt",
        help="Output file to save the poem"
    )
    return parser.parse_args()

def generate_prompt(keywords: List[str], style: str, emotion: Optional[str] = None) -> str:
    """
    Generate a prompt for the model based on keywords, style, and emotion.
    Simplified approach with cleaner prompts.
    """
    keywords_str = ", ".join(keywords)
    
    # Simple style-specific prompt
    if style == "haiku":
        base_prompt = f"Write a haiku about {keywords_str}"
        if emotion:
            base_prompt += f" with a {emotion} feeling"
    elif style == "sonnet":
        base_prompt = f"Write a sonnet about {keywords_str}"
        if emotion:
            base_prompt += f" expressing {emotion}"
    elif style == "limerick":
        base_prompt = f"Write a limerick about {keywords_str}"
        if emotion:
            base_prompt += f" with a {emotion} tone"
    elif style == "ballad":
        base_prompt = f"Write a ballad about {keywords_str}"
        if emotion:
            base_prompt += f" conveying {emotion}"
    elif style == "acrostic":
        # For acrostic, use the first keyword as the base
        acrostic_base = keywords[0].upper()
        base_prompt = f"Write an acrostic poem spelling {acrostic_base}, about {keywords_str}"
        if emotion:
            base_prompt += f" with {emotion} emotion"
    else:  # free verse
        base_prompt = f"Write a free verse poem about {keywords_str}"
        if emotion:
            base_prompt += f" expressing {emotion}"
    
    # Add a line break and a starter line to help the model
    base_prompt += ":\n\n"
    
    return base_prompt

def generate_poem(prompt: str, keywords: List[str] = None, style: str = None, emotion: str = None, retries: int = 3) -> str:
    """
    Generate a poem using gpt2-medium model.
    Simplified generation process with better handling of parameters.
    """
    logger.info("Loading gpt2-medium model")
    
    for attempt in range(retries + 1):
        try:
            logger.info(f"Attempt {attempt+1} to generate a {style} poem")
            
            # Initialize tokenizer and pipeline
            tokenizer = AutoTokenizer.from_pretrained(MODEL_SETTINGS["model_name"])
            tokenizer.pad_token = tokenizer.eos_token
            
            generator = pipeline(
                'text-generation',
                model=MODEL_SETTINGS["model_name"],
                tokenizer=tokenizer,
                device=0 if torch.cuda.is_available() else -1
            )
            
            # Set generation parameters
            params = GENERATION_SETTINGS.copy()
            
            # Adjust based on style
            if style == "haiku":
                params["max_length"] = 150
                params["temperature"] = 0.9
            elif style == "limerick":
                params["max_length"] = 200
                params["temperature"] = 1.2
            elif style == "sonnet":
                params["max_length"] = 250
                params["temperature"] = 1.0
            
            # Generate text
            logger.info(f"Generating with prompt: {prompt[:50]}...")
            outputs = generator(
                prompt,
                max_length=params["max_length"],
                min_length=params["min_length"],
                temperature=params["temperature"],
                top_p=params["top_p"],
                top_k=params["top_k"],
                repetition_penalty=params["repetition_penalty"],
                do_sample=params["do_sample"],
                num_return_sequences=params["num_return_sequences"],
                no_repeat_ngram_size=params["no_repeat_ngram_size"]
            )
            
            # Extract the poem
            generated_text = outputs[0]['generated_text']
            logger.info(f"Raw output length: {len(generated_text)}")
            
            poem = extract_poem_from_text(generated_text, prompt)
            
            # Check if we got a valid poem
            if len(poem) > 20 and "didn't generate" not in poem and "Error" not in poem:
                logger.info(f"Successfully generated a {style} poem")
                # Clean up memory
                del generator, tokenizer
                clean_up_memory()
                return poem
            
            # Try again with shuffled keywords
            if keywords and attempt < retries:
                random.shuffle(keywords)
                prompt = generate_prompt(keywords, style, emotion)
                logger.info(f"Retrying with shuffled keywords: {', '.join(keywords)}")
        
        except Exception as e:
            logger.error(f"Error during generation: {str(e)}")
            
            # Try a simpler approach on next attempt
            if attempt < retries:
                simple_prompt = f"Write a {style} poem about {', '.join(keywords[:2])}"
                prompt = simple_prompt + ":\n\n"
                logger.info(f"Trying with simplified prompt: {simple_prompt}")
    
    return "The model didn't generate a proper poem. Please try with different keywords or style."

def main():
    """Main function."""
    args = parse_arguments()
    keywords = [k.strip() for k in args.keywords.split(",")]
    prompt = generate_prompt(keywords, args.style, args.emotion)
    logger.info("Generating poem with gpt2-medium")
    poem = generate_poem(prompt, keywords, args.style, args.emotion)
    
    # Format the output 
    print("\n=== Generated Poem ===\n")
    
    # Process the poem to ensure proper line breaks for display
    # Split long lines into multiple lines of maximum 60 characters
    formatted_poem = ""
    for line in poem.split('\n'):
        if len(line) > 60:
            words = line.split()
            current_line = ""
            for word in words:
                if len(current_line) + len(word) + 1 > 60:
                    formatted_poem += current_line + "\n"
                    current_line = word
                else:
                    if current_line:
                        current_line += " " + word
                    else:
                        current_line = word
            if current_line:
                formatted_poem += current_line + "\n"
        else:
            formatted_poem += line + "\n"
    
    # Print the formatted poem
    print(formatted_poem)
    
    # Save poem to file with metadata
    metadata = {
        "model": "gpt2-medium",
        "keywords": args.keywords,
        "style": args.style,
        "emotion": args.emotion or "not specified"
    }
    save_path = save_poem_to_file(poem, args.output_file, metadata)
    print(f"\nPoem saved to {save_path}")

if __name__ == "__main__":
    main() 