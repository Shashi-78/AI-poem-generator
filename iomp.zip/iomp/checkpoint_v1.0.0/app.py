"""
AI Poem Generator Web Interface

A simple Flask app that provides a web interface for the poem generation system.
"""

from flask import Flask, render_template, request, jsonify
import os
import sys
from typing import Dict, List, Any
import logging

# Import from our poem generator
from poem_generator import (
    generate_prompt,
    generate_poem
)
from settings import POETRY_STYLES, POETRY_EMOTIONS

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("poem_generator_app")

# Create Flask app
app = Flask(__name__)

@app.route('/')
def index():
    """Render the main page."""
    return render_template(
        'index.html',
        poetry_styles=POETRY_STYLES,
        poetry_emotions=POETRY_EMOTIONS
    )

@app.route('/generate', methods=['POST'])
def generate_poem_route():
    """Generate a poem based on form input."""
    try:
        # Get form data
        keywords = request.form.get('keywords', 'ocean,sunset,silence')
        style = request.form.get('style', 'free verse')
        emotion = request.form.get('emotion', '')
        
        # Validate inputs
        if not keywords:
            return jsonify({'error': 'Keywords are required'}), 400
        
        # Format keywords into a list
        keyword_list = [k.strip() for k in keywords.split(',')]
        
        # Create the prompt
        prompt = generate_prompt(keyword_list, style, emotion if emotion else None)
        
        # Generate the poem
        poem = generate_poem(prompt)
        
        # Return the generated poem
        return jsonify({
            'poem': poem,
            'prompt': prompt,
            'model': 'distilgpt2'
        })
        
    except Exception as e:
        logger.error(f"Error generating poem: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/health')
def health_check():
    """Simple health check endpoint."""
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    # Create templates directory if it doesn't exist
    os.makedirs('templates', exist_ok=True)
    
    # Create basic HTML template if it doesn't exist
    if not os.path.exists('templates/index.html'):
        with open('templates/index.html', 'w') as f:
            f.write('''
<!DOCTYPE html>
<html>
<head>
    <title>AI Poem Generator</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            color: #2c3e50;
            text-align: center;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], select, textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #2980b9;
        }
        .result {
            margin-top: 20px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            white-space: pre-wrap;
            background-color: #f9f9f9;
            display: none;
        }
        .loading {
            text-align: center;
            display: none;
        }
    </style>
</head>
<body>
    <h1>AI Poem Generator</h1>
    
    <form id="poemForm">
        <div class="form-group">
            <label for="keywords">Keywords (comma-separated):</label>
            <input type="text" id="keywords" name="keywords" value="ocean,sunset,silence" required>
        </div>
        
        <div class="form-group">
            <label for="style">Poetry Style:</label>
            <select id="style" name="style">
                {% for style in poetry_styles %}
                <option value="{{ style }}">{{ style }}</option>
                {% endfor %}
            </select>
        </div>
        
        <div class="form-group">
            <label for="emotion">Emotion (optional):</label>
            <select id="emotion" name="emotion">
                <option value="">None</option>
                {% for emotion in poetry_emotions %}
                <option value="{{ emotion }}">{{ emotion }}</option>
                {% endfor %}
            </select>
        </div>
        
        <div class="form-group">
            <button type="button" onclick="generatePoem()">Generate Poem</button>
        </div>
    </form>
    
    <div id="loading" class="loading">
        <p>Generating your poem... This may take a moment.</p>
    </div>
    
    <div id="result" class="result"></div>
    
    <script>
        function generatePoem() {
            const form = document.getElementById('poemForm');
            const formData = new FormData(form);
            
            // Show loading indicator
            document.getElementById('loading').style.display = 'block';
            document.getElementById('result').style.display = 'none';
            
            fetch('/generate', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                // Hide loading indicator
                document.getElementById('loading').style.display = 'none';
                
                // Display result
                const resultDiv = document.getElementById('result');
                
                if (data.error) {
                    resultDiv.innerHTML = `<p style="color: red;">Error: ${data.error}</p>`;
                } else {
                    resultDiv.innerHTML = `
                        <h3>Generated Poem</h3>
                        <div style="white-space: pre-wrap;">${data.poem}</div>
                    `;
                }
                
                resultDiv.style.display = 'block';
            })
            .catch(error => {
                document.getElementById('loading').style.display = 'none';
                document.getElementById('result').style.display = 'block';
                document.getElementById('result').innerHTML = `<p style="color: red;">Error: ${error.message}</p>`;
            });
        }
    </script>
</body>
</html>
            ''')
    
    # Run the app
    app.run(debug=True, host='0.0.0.0', port=5000) 