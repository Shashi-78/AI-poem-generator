"""
Run script for AI Poem Generator.

This script provides an easy way to run either the command line or web interface.
"""

import argparse
import subprocess
import sys
import os

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Run AI Poem Generator")
    parser.add_argument(
        "--web",
        action="store_true",
        help="Run web interface (otherwise runs command line interface)"
    )
    parser.add_argument(
        "--keywords",
        type=str,
        help="Comma-separated keywords for poem generation"
    )
    parser.add_argument(
        "--style",
        type=str,
        help="Poetry style"
    )
    parser.add_argument(
        "--emotion",
        type=str,
        help="Emotion to express in the poem"
    )
    parser.add_argument(
        "--output_file",
        type=str,
        help="Output file to save poem"
    )
    return parser.parse_args()

def run_web_interface():
    """Run the web interface."""
    print("Starting AI Poem Generator web interface...")
    print("Open your browser and go to http://localhost:5000")
    subprocess.run([sys.executable, "app.py"])

def run_command_line(args):
    """Run the command line interface with given arguments."""
    cmd = [sys.executable, "poem_generator.py"]
    
    if args.keywords:
        cmd.extend(["--keywords", args.keywords])
    
    if args.style:
        cmd.extend(["--style", args.style])
    
    if args.emotion:
        cmd.extend(["--emotion", args.emotion])
    
    if args.output_file:
        cmd.extend(["--output_file", args.output_file])
    
    subprocess.run(cmd)

def check_dependencies():
    """Check if all required files exist."""
    required_files = ["poem_generator.py", "app.py", "settings.py", "utils.py"]
    missing_files = [f for f in required_files if not os.path.exists(f)]
    
    if missing_files:
        print(f"Error: Missing required files: {', '.join(missing_files)}")
        print("Please make sure all project files are in the current directory.")
        sys.exit(1)

def main():
    """Main function."""
    # Check if all required files exist
    check_dependencies()
    
    # Parse arguments
    args = parse_arguments()
    
    # Run appropriate interface
    if args.web:
        run_web_interface()
    else:
        run_command_line(args)

if __name__ == "__main__":
    main() 