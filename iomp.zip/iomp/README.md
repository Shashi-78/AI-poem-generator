# AI Poem Generator

Version 2.0.0 (2024-03-19)

An advanced poem generation system using GPT-2 for creating poetry based on user-provided keywords, styles, and emotions.

## Features

- Generate poems in multiple styles (sonnet, haiku, limerick, free verse, ballad, acrostic)
- Add emotional tones to the poems (joy, sadness, love, nostalgia, etc.)
- Provide keywords to guide the content of the generated poems
- Save generated poems to files with metadata

## Usage

```bash
# Generate a sonnet about love, sunset, and ocean with a joyful tone
python poem_generator.py --style "sonnet" --keywords "love,sunset,ocean" --emotion joy

# Create a haiku about mountain, river, and dawn with a sense of wonder
python poem_generator.py --style "haiku" --keywords "mountain,river,dawn" --emotion wonder

# Generate a limerick about journey, adventure, and laughter with a joyful tone
python poem_generator.py --style "limerick" --keywords "journey,adventure,laughter" --emotion joy
```

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Project Structure

- `poem_generator.py`: Core poem generation functionality 
- `utils.py`: Utility functions for text processing and poem extraction
- `settings.py`: Configuration settings
- `outputs/`: Generated poems are saved here

## Recent Improvements

The system has been significantly upgraded to produce higher-quality poems:

1. **Better Generation Settings**: 
   - Optimized temperature, top_p, and other parameters for more coherent poetry
   - Style-specific parameter adjustments for each poetry type

2. **Improved Prompts**:
   - Created distinct, natural prompts for each poetic style
   - Removed excessive instructional text that confused the model
   - Added style-specific prompt templates to guide generation

3. **Enhanced Poem Extraction**:
   - Intelligent content filtering to remove non-poetic elements
   - Better handling of line breaks and paragraph structure
   - Improved poem formatting with proper spacing and punctuation
   - Style-specific extraction logic (e.g., exactly 3 lines for haikus)

4. **Error Handling & Robustness**:
   - Retry logic with shuffled keywords when generation fails
   - Fallback strategies to ensure usable output
   - More comprehensive logging
   - Clean handling of edge cases

## Limitations

- Being based on GPT-2 Medium, the system has inherent limitations compared to larger models
- Highly structured forms (like haiku) may not always follow traditional syllable counts
- Some generated content may need manual review or editing
- Performance depends on the randomness parameters and input keywords

## Future Improvements

- Add support for more poetic forms (villanelle, ode, etc.)
- Implement rhyme scheme analysis for structured poems
- Create syllable counting for haiku and related forms
- Explore fine-tuning GPT-2 specifically for poetry generation

## License

MIT 

## Version History

### V2.0.0 (2024-03-19)
- Enhanced poem generation
- Improved error handling
- Better file management
- Simplified project structure
- Removed alternative execution methods for cleaner codebase 