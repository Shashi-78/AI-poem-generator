"""
Settings for the AI Poem Generator.

This file contains configuration settings for gpt2 model and poem generation.
"""

import os
from pathlib import Path

# Base paths
ROOT_DIR = Path(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = ROOT_DIR / "data"
OUTPUT_DIR = ROOT_DIR / "outputs"

# Create directories if they don't exist
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Model settings
MODEL_SETTINGS = {
    # Using gpt2-medium for better quality
    "model_name": "gpt2-medium",
    "model_kwargs": {
        "pad_token_id": 50256,
        "bos_token_id": 50256,
        "eos_token_id": 50256
    }
}

# Poem generation settings - optimized for poetry
GENERATION_SETTINGS = {
    "max_length": 150,      # Shorter length for more focused content
    "min_length": 50,       # Reasonable minimum length
    "temperature": 0.9,     # Lower temperature for more coherent output
    "top_p": 0.85,          # More restrictive sampling for better quality
    "top_k": 40,            # Balanced top_k
    "repetition_penalty": 1.4,  # Increased to prevent repetition
    "num_return_sequences": 1,
    "do_sample": True,
    "no_repeat_ngram_size": 3,  # Avoid repeating 3-word phrases
    "truncation": True      # Add explicit truncation
}

# Poetry styles
POETRY_STYLES = [
    "free verse",
    "haiku",
    "sonnet",
    "limerick",
    "ballad",
    "acrostic",
    "ode",
    "elegy",
    "villanelle",
    "tanka"
]

# Emotions for poetry
POETRY_EMOTIONS = [
    "joy",
    "sadness",
    "love",
    "longing",
    "hope",
    "despair",
    "nostalgia",
    "wonder",
    "anger",
    "serenity",
    "melancholy"
]

# Style-specific prompts - more poetic and natural
DEFAULT_PROMPTS = {
    "free_verse": "A free verse poem about {keywords}. The words flow naturally with emotion and imagery.",
    "haiku": "A haiku about {keywords}. Three lines with 5-7-5 syllable pattern, capturing a moment in nature.",
    "sonnet": "A sonnet about {keywords}. Fourteen lines with a rhyme scheme, expressing deep feelings.",
    "limerick": "A limerick about {keywords}. Five lines with an AABBA rhyme scheme, often humorous and rhythmic.",
    "ballad": "A ballad about {keywords}. A narrative poem telling a story with strong rhythm and often repeated refrains.",
    "acrostic": "An acrostic poem spelling {acrostic_word}, about {keywords}. Each line begins with a letter of the word."
} 