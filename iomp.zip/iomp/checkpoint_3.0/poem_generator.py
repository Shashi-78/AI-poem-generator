"""
AI Poem Generator

A streamlined poem generation system using gpt2 for generating poetry based on user-provided keywords.
"""

import argparse
import os
import torch
from transformers import pipeline, AutoTokenizer
from pathlib import Path
import logging
from typing import Dict, List, Optional, Any
import random
from datetime import datetime

# Import settings and utilities
from settings import GENERATION_SETTINGS, OUTPUT_DIR, MODEL_SETTINGS, DEFAULT_PROMPTS
from utils import (
    clean_up_memory,
    extract_poem_from_text,
    preprocess_text,
    save_poem_to_file
)

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("poem_generator")

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="AI Poem Generator")
    parser.add_argument(
        "--keywords",
        type=str,
        default="ocean,sunset,silence",
        help="Comma-separated keywords for the poem"
    )
    parser.add_argument(
        "--style",
        type=str,
        default="free verse",
        choices=["free verse", "haiku", "sonnet", "limerick", "ballad", "acrostic"],
        help="Poetry style"
    )
    parser.add_argument(
        "--emotion",
        type=str,
        default=None,
        help="Emotion to express in the poem"
    )
    parser.add_argument(
        "--output_file",
        type=str,
        default="generated_poem.txt",
        help="Output file to save the poem"
    )
    return parser.parse_args()

def create_prompt(keywords, style, emotion):
    """Create a prompt for poem generation with unique starter lines."""
    # Convert keywords to a list if it's a string
    if isinstance(keywords, str):
        keywords_list = [k.strip() for k in keywords.split(",") if k.strip()]
    else:
        keywords_list = keywords

    # Define various sentence patterns
    patterns = [
        "{noun} {verb} in the {place}",
        "Through {place}, {noun} {verb}",
        "When {noun} {verb}, {place} {verb}",
        "In the {place}, {noun} {verb}",
        "{noun} {verb} through {place}",
        "As {noun} {verb}, {place} {verb}",
        "{place} {verb} with {noun}",
        "{noun} and {place} {verb} together"
    ]

    # Define verbs based on emotion
    emotion_verbs = {
        "power": ["thunders", "crashes", "roars", "strikes", "surges", "booms", "resonates"],
        "mystery": ["whispers", "shimmers", "fades", "drifts", "hides", "lingers", "echoes"],
        "joy": ["dances", "sparkles", "laughs", "sings", "plays", "twirls", "shines"],
        "serenity": ["flows", "drifts", "floats", "rests", "settles", "calms", "soothes"],
        "hope": ["rises", "glows", "dawns", "awakens", "emerges", "shines", "breathes"],
        "delight": ["twirls", "spins", "dances", "sparkles", "shines", "laughs", "plays"],
        "fury": ["rages", "storms", "thrashes", "howls", "roars", "crashes", "strikes"],
        "peace": ["settles", "calms", "soothes", "rests", "quiets", "flows", "drifts"],
        "energy": ["pulses", "vibrates", "thrums", "beats", "surges", "flows", "moves"],
        "nostalgia": ["drifts", "lingers", "echoes", "remembers", "recalls", "fades", "whispers"],
        "wonder": ["sparkles", "shimmers", "glows", "dances", "floats", "rises", "flows"],
        "longing": ["yearns", "reaches", "stretches", "aches", "dreams", "calls", "whispers"]
    }

    # Define places and settings
    places = [
        "night", "light", "breeze", "silence", "distance",
        "shadows", "waves", "leaves", "clouds", "dreams",
        "dawn", "dusk", "twilight", "horizon", "sky",
        "wind", "rain", "storm", "sun", "moon"
    ]

    # Get verbs for the emotion
    verbs = emotion_verbs.get(emotion.lower(), ["flows", "dances", "drifts", "shimmers", "echoes"])

    # Build the poem lines
    if style == "haiku":
        base_prompt = f"Write a haiku about {', '.join(keywords_list)} with a sense of {emotion}.\n\n"
        if len(keywords_list) >= 3:
            # Create three unique lines using different patterns
            line1 = random.choice(patterns).format(
                noun=keywords_list[0].capitalize(),
                verb=random.choice(verbs),
                place=random.choice(places)
            )
            line2 = random.choice(patterns).format(
                noun=keywords_list[1].capitalize(),
                verb=random.choice(verbs),
                place=random.choice(places)
            )
            line3 = random.choice(patterns).format(
                noun=keywords_list[2].capitalize(),
                verb=random.choice(verbs),
                place=random.choice(places)
            )
            base_prompt += f"{line1},\n{line2},\n{line3}.\n\n"
        else:
            base_prompt += "Haiku lines here.\n\n"
    else:  # free verse and others
        base_prompt = f"Write a {style} poem about {', '.join(keywords_list)} with a feeling of {emotion}.\n\n"
        if len(keywords_list) >= 3:
            # Create three unique lines using different patterns
            line1 = random.choice(patterns).format(
                noun=keywords_list[0].capitalize(),
                verb=random.choice(verbs),
                place=random.choice(places),
                verb2=random.choice(verbs)
            )
            line2 = random.choice(patterns).format(
                noun=keywords_list[1].capitalize(),
                verb=random.choice(verbs),
                place=random.choice(places),
                verb2=random.choice(verbs)
            )
            line3 = random.choice(patterns).format(
                noun=keywords_list[2].capitalize(),
                verb=random.choice(verbs),
                place=random.choice(places),
                verb2=random.choice(verbs)
            )
            base_prompt += f"{line1},\n{line2},\n{line3}.\n\n"
        else:
            base_prompt += "Poem lines here.\n\n"
    
    return base_prompt

def generate_text(prompt):
    """Generate text using the GPT-2 model."""
    # Initialize tokenizer and pipeline
    tokenizer = AutoTokenizer.from_pretrained(MODEL_SETTINGS["model_name"])
    tokenizer.pad_token = tokenizer.eos_token
    
    generator = pipeline(
        'text-generation',
        model=MODEL_SETTINGS["model_name"],
        tokenizer=tokenizer,
        device=0 if torch.cuda.is_available() else -1
    )
    
    # Generate text
    outputs = generator(
        prompt,
        max_length=GENERATION_SETTINGS["max_length"],
        min_length=GENERATION_SETTINGS["min_length"],
        temperature=GENERATION_SETTINGS["temperature"],
        top_p=GENERATION_SETTINGS["top_p"],
        top_k=GENERATION_SETTINGS["top_k"],
        repetition_penalty=GENERATION_SETTINGS["repetition_penalty"],
        do_sample=GENERATION_SETTINGS["do_sample"],
        num_return_sequences=GENERATION_SETTINGS["num_return_sequences"],
        no_repeat_ngram_size=GENERATION_SETTINGS["no_repeat_ngram_size"]
    )
    
    # Clean up memory
    del generator, tokenizer
    clean_up_memory()
    
    return outputs[0]['generated_text']

def generate_poem(keywords, style="free verse", emotion="neutral"):
    """Generate a poem based on keywords, style, and emotion."""
    try:
        # Create the prompt with starter lines
        prompt = create_prompt(keywords, style, emotion)
        
        # Generate the poem
        generated_text = generate_text(prompt)
        
        # Extract just the starter lines (the actual poem)
        poem = extract_poem_from_text(generated_text)
        
        # Save to file without author attribution
        save_poem_to_file(poem, keywords, style, emotion)
        
        return poem
    except Exception as e:
        print(f"Error generating poem: {str(e)}")
        return None

def save_poem_to_file(poem, keywords, style, emotion):
    """Save the generated poem to a file."""
    try:
        # Create outputs directory if it doesn't exist
        os.makedirs("outputs", exist_ok=True)
        
        # Create filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"outputs/generated_poem_{timestamp}.txt"
        
        # Write poem to file
        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"Keywords: {keywords}\n")
            f.write(f"Style: {style}\n")
            f.write(f"Emotion: {emotion}\n")
            f.write("\n")
            f.write(poem)
            f.write("\n")
        
        print(f"Poem saved to {filename}")
    except Exception as e:
        print(f"Error saving poem to file: {str(e)}")

def main():
    """Main function."""
    args = parse_arguments()
    keywords = [k.strip() for k in args.keywords.split(",")]
    prompt = create_prompt(keywords, args.style, args.emotion)
    logger.info("Generating poem with gpt2-medium")
    poem = generate_poem(keywords, args.style, args.emotion)
    
    # Format the output 
    print("\n=== Generated Poem ===\n")
    
    # Process the poem to ensure proper line breaks for display
    # Split long lines into multiple lines of maximum 60 characters
    formatted_poem = ""
    for line in poem.split('\n'):
        if len(line) > 60:
            words = line.split()
            current_line = ""
            for word in words:
                if len(current_line) + len(word) + 1 > 60:
                    formatted_poem += current_line + "\n"
                    current_line = word
                else:
                    if current_line:
                        current_line += " " + word
                    else:
                        current_line = word
            if current_line:
                formatted_poem += current_line + "\n"
        else:
            formatted_poem += line + "\n"
    
    # Print the formatted poem
    print(formatted_poem)
    
    # Save poem to file with metadata
    metadata = {
        "model": "gpt2-medium",
        "keywords": args.keywords,
        "style": args.style,
        "emotion": args.emotion or "not specified"
    }
    save_path = save_poem_to_file(poem, args.keywords, args.style, args.emotion)
    print(f"\nPoem saved to {save_path}")

if __name__ == "__main__":
    main() 