# Checkpoint 3.0 - AI Poem Generator

This checkpoint represents the state of the AI Poem Generator project before the addition of performance graphs and visualization features.

## Contents

1. `poem_generator.py` - Main poem generation script
2. `utils.py` - Utility functions for text processing and file operations
3. `settings.py` - Configuration settings for the model and poem generation
4. `requirements.txt` - Project dependencies

## Features

- GPT-2 based poem generation
- Multiple poetry style support
- Emotion integration
- Keyword-based generation
- Quality control measures
- File output capabilities

## Usage

To generate a poem:
```bash
python poem_generator.py --keywords "ocean,sunset,silence" --style "haiku" --emotion "serenity"
```

## Dependencies

All required dependencies are listed in `requirements.txt`. Install them using:
```bash
pip install -r requirements.txt
``` 