"""
Utility functions for the AI Poem Generator.

This file contains helper functions for text processing, poem extraction, and memory management.
"""

import re
import torch
import os
import logging
from typing import List, Dict, Any, Optional

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("poem_generator")

def clean_up_memory() -> None:
    """Clean up GPU memory."""
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        logger.info("GPU memory cleared")

def preprocess_text(text: str) -> str:
    """
    Clean and normalize text.
    
    Args:
        text: Input text
        
    Returns:
        Cleaned text
    """
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text.strip())
    
    # Remove URLs
    text = re.sub(r'http\S+|www\S+|https\S+', '', text)
    
    # Remove special characters but preserve poetry punctuation
    text = re.sub(r'[^\w\s.,;:!?\'"-]', ' ', text)
    
    # Normalize whitespace again
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

def post_process_poem(poem: str) -> str:
    """Improved post-processing function that formats the poem with proper line breaks."""
    lines = poem.split('\n')
    processed = []
    
    for line in lines:
        # Clean up whitespace
        line = line.strip()
        if not line:
            continue
            
        # Fix line breaks in the middle of sentences
        if len(processed) > 0 and not processed[-1].endswith(('.', '!', '?', ':', ';', '-', '—')):
            # If previous line doesn't end with punctuation and this line starts with lowercase
            if not line[0].isupper() and not line[0].isdigit():
                # Append to previous line instead of creating a new one
                processed[-1] += ' ' + line
                continue
        
        processed.append(line)
        
    return '\n'.join(processed)

def extract_poem_from_text(text: str) -> str:
    """
    Extract the poem from the generated text.
    Removes instruction lines and keeps only the poetic lines.
    """
    try:
        # Split the text into lines
        lines = text.strip().split('\n')
        
        # Filter out instruction lines and empty lines
        poem_lines = []
        for line in lines:
            line = line.strip()
            # Skip empty lines and instruction lines
            if not line or line.startswith('Write a') or line.startswith('POEM ABOUT'):
                continue
            poem_lines.append(line)
            if len(poem_lines) == 3:  # Keep only the first three poetic lines
                break
        
        # Join the lines to form the poem
        poem = '\n'.join(poem_lines)
        
        return poem
    except Exception as e:
        logger.error(f"Error extracting poem: {str(e)}")
        return "Error extracting poem. Please try again."

def save_poem_to_file(poem: str, filename: str, metadata: Optional[Dict[str, Any]] = None) -> str:
    """
    Save a generated poem to a file with optional metadata.
    Always creates the outputs directory if it doesn't exist.
    """
    # Ensure the output directory exists
    output_dir = 'outputs'
    os.makedirs(output_dir, exist_ok=True)
    
    # Add .txt extension if not present
    if not filename.endswith('.txt'):
        filename += '.txt'
    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write("=== Generated Poem ===\n\n")
        if metadata:
            f.write("Generated with:\n")
            for key, value in metadata.items():
                f.write(f"- {key}: {value}\n")
            f.write("\n")
        
        # Write poem with proper line breaks
        f.write(poem)
    logger.info(f"Poem saved to {filepath}")
    return filepath 